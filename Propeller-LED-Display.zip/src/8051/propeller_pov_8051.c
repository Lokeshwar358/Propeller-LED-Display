
/* 8051 (AT89S52) Keil C example (conceptual)
   - Uses external interrupt 0 (P3.2) for Hall sensor
   - Uses PORT1 for 8 LEDs (or use shift register with SPI bit-bang)
   - Timer0 used for timing columns
*/

#include <reg51.h>
#include <intrins.h>
#define HALL_PIN P3_2
#define LED_PORT P1

volatile unsigned int revolutionPeriod = 20000; // microseconds approx
volatile bit indexDetected = 0;

unsigned char message[] = {0x7E,0x08,0x08,0x08,0x7E,0x00, 0x00,0x00,0x7E,0x00,0x00,0x00};
unsigned char messageLen = sizeof(message);

void External0_ISR(void) interrupt 0 using 1 {
    static unsigned long last=0;
    unsigned long now = 0; // using timer capture not shown; conceptually get current microseconds
    // For simplicity, flip flag
    indexDetected = 1;
}

void delay_us(unsigned int us) {
    // Implement busy-wait microsecond delay based on crystal
    while(us--) {
        _nop_(); _nop_(); _nop_();
    }
}

void main(void){
    EA = 1;
    EX0 = 1; // enable external interrupt 0
    while(1){
        if(indexDetected){
            indexDetected = 0;
            unsigned int timePerColumn = revolutionPeriod / messageLen;
            for(unsigned char i=0;i<messageLen;i++){
                LED_PORT = message[i]; // direct drive (use resistors and drivers)
                delay_us(timePerColumn);
            }
        }
    }
}
