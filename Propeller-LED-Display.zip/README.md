
# Propeller LED Display (POV)

A Persistence-of-Vision (POV) rotating LED display using Arduino / 8051 / LPC2148.

## Features
- 8/16 LED rotating propeller display
- Hall/IR sensor based synchronization
- Code for Arduino, 8051, LPC2148
- Shift register (74HC595) LED driving
- Motor PWM control

## Repository Structure
```
Propeller-LED-Display/
 ├── README.md
 ├── src/
 │    ├── Arduino/
 │    ├── 8051/
 │    ├── LPC2148/
 ├── docs/
 ├── images/
```

## How It Works
A linear LED strip rotates at high speed. The microcontroller updates LED patterns at precise angular positions using a hall sensor index pulse.

## Hardware Required
- Arduino / ATmega328 / 8051 / LPC2148
- 74HC595 or ULN2003
- Motor + driver
- Hall sensor
- Power supply
- Propeller blade

See full PDF documentation inside `docs/`.
